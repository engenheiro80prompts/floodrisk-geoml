# 🌊 FloodRisk GeoML

> **Mapeamento preditivo de risco de alagamento urbano** com Machine Learning e dados geoespaciais — Região Metropolitana de São Paulo

[![Python](https://img.shields.io/badge/Python-3.10+-3776AB?logo=python&logoColor=white)](https://python.org)
[![scikit-learn](https://img.shields.io/badge/scikit--learn-1.3+-F7931E?logo=scikit-learn&logoColor=white)](https://scikit-learn.org)
[![GeoPandas](https://img.shields.io/badge/GeoPandas-0.14+-139C5A)](https://geopandas.org)
[![Folium](https://img.shields.io/badge/Folium-0.15+-77B829)](https://python-visualization.github.io/folium)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 📌 Visão Geral

Este projeto aplica **Random Forest com features geoespaciais e hidrológicas** para classificar setores censitários da RMSP por nível de risco de alagamento — produzindo um mapa interativo choropleth que permite identificar zonas críticas por bairro e município.

**Motivação técnica:** Eventos de alagamento urbano na RMSP causam, em média, prejuízos superiores a R$ 1 bilhão/ano (CGE-SP). A antecipação de áreas de risco por meio de dados geoespaciais e ML oferece base quantitativa para ações de drenagem urbana, planos diretores e defesa civil.

---

## 🗂️ Estrutura do Projeto

```
floodrisk-geoml/
│
├── data/
│   ├── raw/                          # Dataset original (setores censitários)
│   └── processed/                    # Predições e scores do modelo
│
├── src/
│   ├── generate_data.py              # Geração do dataset sintético realista
│   ├── train_model.py                # Pipeline ML: treino, avaliação, visualizações
│   └── generate_map.py               # Mapa interativo Folium
│
├── dashboard/
│   └── mapa_risco.html               # Mapa interativo (abrir no browser)
│
├── docs/
│   ├── feature_importance_roc.png    # Importância das variáveis + Curva ROC
│   ├── risco_por_municipio.png       # Distribuição de risco por município
│   └── confusion_matrix.png          # Matriz de confusão
│
├── notebooks/
│   └── exploratory_analysis.ipynb   # Análise exploratória completa
│
├── requirements.txt
└── README.md
```

---

## 🔬 Variáveis do Modelo

| Feature | Fonte de referência | Relevância hidrológica |
|---|---|---|
| `declividade_graus` | MDT/SRTM (IBGE) | Controla velocidade de escoamento superficial |
| `dist_drenagem_m` | Carta hidrológica | Proximidade a cursos d'água — risco de transbordamento |
| `impermeabilizacao_pct` | Uso do solo (MapBiomas) | Reduz infiltração, aumenta runoff |
| `altitude_relativa_m` | MDT local | Cotas baixas acumulam escoamento |
| `precipitacao_max_24h_mm` | INMET — séries históricas | Intensidade de evento extremo |
| `capacidade_drenagem_idx` | PDDU municipal | Capacidade da infraestrutura instalada |
| `densidade_pop_hab_km2` | Censo IBGE 2022 | Pressão sobre sistema de drenagem |
| `tempo_concentracao_min` | Cálculo hidrológico | Velocidade de resposta da bacia |
| `cobertura_vegetal_pct` | MapBiomas | Permeabilidade e retenção |
| `manut_microdrenagem_idx` | Defesa Civil/PMSP | Estado operacional da rede |

**Target:** `risco_alto` — binário (≥ 3 ocorrências de alagamento em 5 anos)

---

## 🤖 Modelo

```
Random Forest Classifier
├── n_estimators : 300
├── max_depth    : 8
├── class_weight : balanced
└── random_state : 42

Métricas no conjunto de teste (25%):
├── ROC-AUC  : 0.705
├── CV AUC   : 0.663 ± 0.052  (StratifiedKFold, k=5)
├── Precision (Alto Risco): 0.83
└── Recall   (Alto Risco): 0.92
```

---

## 🗺️ Mapa Interativo

Abra `dashboard/mapa_risco.html` no browser para explorar:

- **Círculos coloridos** por nível de risco (vermelho crítico → verde baixo)
- **Popup detalhado** por setor: probabilidade, ocorrências históricas, features principais
- **Camada HeatMap** alternativa para visão de densidade
- **Painel de resumo** com contagem por categoria de risco

![Legenda de risco](docs/feature_importance_roc.png)

---

## 🚀 Como Executar

```bash
# 1. Clone o repositório
git clone https://github.com/seu-usuario/floodrisk-geoml.git
cd floodrisk-geoml

# 2. Instale as dependências
pip install -r requirements.txt

# 3. Gere o dataset
python src/generate_data.py

# 4. Treine o modelo e gere visualizações
python src/train_model.py

# 5. Gere o mapa interativo
python src/generate_map.py

# 6. Abra o mapa
open dashboard/mapa_risco.html   # macOS
xdg-open dashboard/mapa_risco.html  # Linux
```

---

## 📊 Resultados

![Feature Importance e ROC](docs/feature_importance_roc.png)

As três variáveis de maior importância foram:
1. **Impermeabilização (%)** — maior bloqueio à infiltração
2. **Distância ao curso d'água** — fator de exposição direta
3. **Capacidade de drenagem** — gargalo infraestrutural

![Risco por Município](docs/risco_por_municipio.png)

---

## 🔄 Próximos Passos

- [ ] Integrar dados reais: INMET (precipitação), IBGE (MDT), Defesa Civil SP (ocorrências)
- [ ] Adicionar feature de `CN curve number` (USDA) por tipo de solo
- [ ] Testar XGBoost + SHAP values para interpretabilidade
- [ ] Pipeline de atualização automática com dados pluviométricos em tempo real (API REDEMET)
- [ ] Deploy como WebApp com Streamlit ou Flask

---

## 🏗️ Contexto Técnico

Projeto desenvolvido como demonstração da interseção entre **engenharia civil** e **ciência de dados**, com foco em drenagem urbana. As variáveis foram selecionadas com base nos parâmetros utilizados em estudos hidrológicos do DAEE-SP e metodologias de mapeamento de risco da ABNT NBR 11682.

> ⚠️ **Nota:** O dataset utilizado é **sintético**, gerado com distribuições baseadas em parâmetros reais da RMSP. Os resultados servem como prova de conceito metodológica.

---

## 👤 Autor

**Alexandre Miranda Gomes da Silva**  
Engenheiro Civil · CREA/SP 5070186710  
Especialista em regularização fundiária e aplicações de IA em engenharia  

[![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?logo=linkedin&logoColor=white)](https://linkedin.com)
[![GitHub](https://img.shields.io/badge/GitHub-181717?logo=github&logoColor=white)](https://github.com)

---

## 📄 Licença

MIT License — veja [LICENSE](LICENSE) para detalhes.
